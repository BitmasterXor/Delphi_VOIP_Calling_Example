# vcp
Voice Communicator Components, public full sources release.

Sources are released in hope they will be usefull.

Feel free to explore and experiment.

Should be compatible with Delphi 7 - Delphi 10 (Seattle).


# installation

1. Open vc2/vc2.dpk
2. Right click - Options... - Search path - add "../common"
3. Right click - Install

# running a sample

1. Open a sample project (for example samples\vcVoiceChat\vcVoiceChat.dpr)
2. Add "../../common;../../vc2" to Search path
3. Run
